//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDR_MANIFEST                    1
#define IDD_DIALOG                      101
#define IDI_ICON                        102
#define IDC_SOURCE                      1001
#define IDC_SYSLANGLIST                 1002
#define IDC_INTLANGLIST                 1003
#define IDC_INFO                        1004
#define IDC_LANGID                      1005
#define IDC_CODEPAGE                    1006
#define IDC_COPYHELPER                  1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
